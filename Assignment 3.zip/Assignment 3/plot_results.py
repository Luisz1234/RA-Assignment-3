import matplotlib.pyplot as plt
import pandas as pd
import os

def plot_file(filename, title, xlabel, output):
    if not os.path.exists(filename): return
    try:
        data = pd.read_csv(filename, sep='\t', comment='#', names=['Param', 'Error', 'StdDev'])
        plt.figure(figsize=(10, 6))
        plt.errorbar(data['Param'], data['Error'], yerr=data['StdDev'], fmt='-o', ecolor='red', capsize=5)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel('Relative Error (%)')
        plt.xscale('log', base=2)
        plt.grid(True, which="both", ls="--")
        plt.savefig(output)
        print(f'Generated {output}')
    except Exception as e: print(f'Skipping plot: {e}')

plot_file('hll_results.dat', 'HyperLogLog Error vs m', 'Registers (m)', 'hll_plot.png')
plot_file('rec_results.dat', 'Recordinality Error vs k', 'Sample Size (k)', 'rec_plot.png')
