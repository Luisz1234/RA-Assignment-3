/*
 * Randomized Algorithms (RA-MIRI) - Assignment #3
 * Final Version: HLL + Recordinality + Bonus Algorithms + Analysis
 * * CHANGES:
 * - Added Standard Deviation (StdDev %) column to analyze stability.
 * - Added RecordinalityRaw (no hashing) to test the random permutation hypothesis.
 * - Refined table formatting.
 */

#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <random>
#include <cstdint>
#include <iomanip>
#include <numeric> // For variance calculations

// Includes for MSVC specific intrinsics
#ifdef _MSC_VER
#include <intrin.h>
#pragma intrinsic(_BitScanReverse64)
#endif

using namespace std;

// =========================================================
// Cross-Platform Bit Manipulation
// =========================================================

int count_leading_zeros(uint64_t x) {
    if (x == 0) return 64;
#ifdef _MSC_VER
    unsigned long index;
    _BitScanReverse64(&index, x);
    return 63 - index;
#else
    return __builtin_clzll(x);
#endif
}

// =========================================================
// Hashing (MurmurHash2 64-bit)
// =========================================================

uint64_t MurmurHash64A(const void* key, int len, unsigned int seed) {
    const uint64_t m = 0xc6a4a7935bd1e995;
    const int r = 47;
    uint64_t h = seed ^ (len * m);
    const uint64_t* data = (const uint64_t*)key;
    const uint64_t* end = data + (len / 8);

    while (data != end) {
        uint64_t k = *data++;
        k *= m; k ^= k >> r; k *= m;
        h ^= k; h *= m;
    }
    const unsigned char* data2 = (const unsigned char*)data;
    switch (len & 7) {
    case 7: h ^= uint64_t(data2[6]) << 48;
    case 6: h ^= uint64_t(data2[5]) << 40;
    case 5: h ^= uint64_t(data2[4]) << 32;
    case 4: h ^= uint64_t(data2[3]) << 24;
    case 3: h ^= uint64_t(data2[2]) << 16;
    case 2: h ^= uint64_t(data2[1]) << 8;
    case 1: h ^= uint64_t(data2[0]); h *= m;
    };
    h ^= h >> r; h *= m; h ^= h >> r;
    return h;
}

uint64_t hash_str(const string& s, unsigned int seed) {
    return MurmurHash64A(s.c_str(), s.length(), seed);
}

// =========================================================
// Algorithms
// =========================================================

class CardinalityEstimator {
public:
    virtual void add(const string& s) = 0;
    virtual double estimate() = 0;
    virtual string name() const = 0;
    virtual ~CardinalityEstimator() {}
};

// --- HyperLogLog ---
class HyperLogLog : public CardinalityEstimator {
    int b, m;
    double alpha_m;
    vector<int> registers;
    unsigned int seed;

public:
    HyperLogLog(int b_bits, unsigned int seed_val) : b(b_bits), seed(seed_val) {
        m = 1 << b;
        registers.resize(m, 0);
        if (m == 16) alpha_m = 0.673;
        else if (m == 32) alpha_m = 0.697;
        else if (m == 64) alpha_m = 0.709;
        else alpha_m = 0.7213 / (1.0 + 1.079 / m);
    }

    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        uint32_t idx = h & (m - 1);
        uint64_t w = h >> b;
        int rank = count_leading_zeros(w) - b + 1; 
        if (rank > registers[idx]) registers[idx] = rank;
    }

    double estimate() override {
        double sum_inv = 0.0;
        for (int val : registers) sum_inv += pow(2.0, -val);
        double E = alpha_m * m * m / sum_inv;
        if (E <= 2.5 * m) {
            int V = 0;
            for (int v : registers) if (v == 0) V++;
            if (V > 0) E = m * log((double)m / V);
        }
        return E;
    }
    string name() const override { return "HLL"; }
};

// --- Recordinality (Standard Hashed) ---
class Recordinality : public CardinalityEstimator {
    int k;
    int R; 
    unsigned int seed;
    unordered_set<uint64_t> sample;
    uint64_t current_min;

    void update_min() {
        uint64_t m_val = UINT64_MAX;
        for (auto v : sample) if (v < m_val) m_val = v;
        current_min = m_val;
    }

public:
    Recordinality(int k_val, unsigned int seed_val) 
        : k(k_val), R(0), seed(seed_val), current_min(UINT64_MAX) {}

    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        if (sample.size() < (size_t)k) {
            if (sample.find(h) == sample.end()) {
                sample.insert(h);
                R++;
                update_min();
            }
        } else {
            if (h > current_min && sample.find(h) == sample.end()) {
                sample.erase(current_min);
                sample.insert(h);
                update_min();
                R++;
            }
        }
    }

    double estimate() override {
        double exponent = (double)R - k;
        if (exponent < 0) exponent = 0;
        return k * pow(1.0 + 1.0 / k, exponent) - 1;
    }
    string name() const override { return "REC"; }
};

// --- Recordinality Raw (NO HASH - Lexicographical) 
class RecordinalityRaw : public CardinalityEstimator {
    int k;
    int R;
    set<string> sample; 

public:
    RecordinalityRaw(int k_val) : k(k_val), R(0) {}

    void add(const string& s) override {
        if (sample.size() < (size_t)k) {
            if (sample.find(s) == sample.end()) {
                sample.insert(s);
                R++;
            }
        } else {
            string current_max = *sample.rbegin();
            
            if (s < current_max && sample.find(s) == sample.end()) {
                sample.erase(prev(sample.end())); // Remove largest
                sample.insert(s);
                R++;
            }
        }
    }

    double estimate() override {
        double exponent = (double)R - k;
        if (exponent < 0) exponent = 0;
        return k * pow(1.0 + 1.0 / k, exponent) - 1;
    }
    string name() const override { return "REC-Raw"; }
};

// --- PCSA ---
class PCSA : public CardinalityEstimator {
    int b, m;
    vector<uint32_t> bitmaps;
    unsigned int seed;
    double phi = 0.77351;

public:
    PCSA(int b_bits, unsigned int seed_val) : b(b_bits), seed(seed_val) {
        m = 1 << b;
        bitmaps.resize(m, 0);
    }
    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        uint32_t idx = h >> (64 - b);
        uint64_t w = h << b; 
        int rho = count_leading_zeros(w); 
        if (rho > 31) rho = 31;
        bitmaps[idx] |= (1 << rho);
    }
    double estimate() override {
        double sum_R = 0.0;
        for (uint32_t bitmap : bitmaps) {
            int R = 0;
            while ((bitmap >> R) & 1) R++;
            sum_R += (double)R;
        }
        double avg_R = sum_R / (double)m;
        return (m / phi) * pow(2.0, avg_R);
    }
    string name() const override { return "PCSA"; }
};

// --- KMV ---
class KMV : public CardinalityEstimator {
    int k;
    unsigned int seed;
    set<uint64_t> k_min_values;

public:
    KMV(int k_val, unsigned int seed_val) : k(k_val), seed(seed_val) {}
    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        if (k_min_values.size() < (size_t)k) {
            k_min_values.insert(h);
        } else {
            uint64_t current_max = *k_min_values.rbegin();
            if (h < current_max && k_min_values.find(h) == k_min_values.end()) {
                k_min_values.erase(current_max);
                k_min_values.insert(h);
            }
        }
    }
    double estimate() override {
        if (k_min_values.size() < (size_t)k) return (double)k_min_values.size();
        uint64_t kth_hash = *k_min_values.rbegin();
        if (kth_hash == 0) return 0;
        double ratio = (double)UINT64_MAX / (double)kth_hash;
        return (k - 1) * ratio;
    }
    string name() const override { return "KMV"; }
};

// --- MinCount ---
class MinCount : public CardinalityEstimator {
    int m;
    unsigned int seed;
    vector<uint64_t> buckets;

public:
    MinCount(int m_val, unsigned int seed_val) : m(m_val), seed(seed_val) {
        buckets.resize(m, UINT64_MAX);
    }
    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        uint32_t idx = h % m; 
        if (h < buckets[idx]) buckets[idx] = h;
    }
    double estimate() override {
        double sum_min = 0.0;
        int empty_buckets = 0;
        for (uint64_t val : buckets) {
            if (val == UINT64_MAX) empty_buckets++;
            else sum_min += (double)val / (double)UINT64_MAX;
        }
        if (empty_buckets > 0) return m * log((double)m / empty_buckets);
        return (m * (m - 1)) / sum_min;
    }
    string name() const override { return "MinCount"; }
};

// --- Adaptive Sampling ---
class AdaptiveSampling : public CardinalityEstimator {
    int k;
    unsigned int seed;
    uint64_t max_hash = UINT64_MAX;
    set<uint64_t> sample;

public:
    AdaptiveSampling(int k_val, unsigned int seed_val) : k(k_val), seed(seed_val) {}
    void add(const string& s) override {
        uint64_t h = hash_str(s, seed);
        if (h >= max_hash) return;
        sample.insert(h);
        if (sample.size() > (size_t)k) {
            auto it = sample.end();
            it--; 
            max_hash = *it;
            sample.erase(it);
        }
    }
    double estimate() override {
        if (sample.empty()) return 0;
        if (max_hash == 0) return 1.0;
        double fraction = (double)max_hash / (double)UINT64_MAX;
        return (double)sample.size() / fraction;
    }
    string name() const override { return "Adaptive"; }
};

// =========================================================
// File & Stats Helpers
// =========================================================

struct StatResult {
    double avg;
    double std_dev;
    double rel_error;
    double std_dev_percent;
};

StatResult compute_stats(const vector<double>& estimates, size_t true_card) {
    double sum = accumulate(estimates.begin(), estimates.end(), 0.0);
    double mean = sum / estimates.size();
    
    double sq_sum = inner_product(estimates.begin(), estimates.end(), estimates.begin(), 0.0);
    double stdev = sqrt(sq_sum / estimates.size() - mean * mean);

    StatResult res;
    res.avg = mean;
    res.std_dev = stdev;
    res.rel_error = abs(mean - (double)true_card) / true_card * 100.0;
    res.std_dev_percent = (stdev / true_card) * 100.0; // StdDev relative to true card
    return res;
}

vector<string> load_file(const string& filepath) {
    vector<string> words;
    ifstream file(filepath);
    if (!file.is_open()) {
        cerr << "Warning: Could not open " << filepath << endl;
        return words;
    }
    string token;
    while (file >> token) {
        words.push_back(token);
    }
    return words;
}

size_t get_cardinality_from_dat(const string& filepath) {
    ifstream file(filepath);
    if (!file.is_open()) return 0;
    size_t count = 0;
    string line;
    while (getline(file, line)) if (!line.empty()) count++;
    return count;
}

void generate_plot_script() {
    ofstream py("plot_results.py");
    py << "import matplotlib.pyplot as plt\nimport pandas as pd\nimport os\n\n";
    py << "def plot_file(filename, title, xlabel, output):\n";
    py << "    if not os.path.exists(filename): return\n";
    py << "    try:\n";
    py << "        data = pd.read_csv(filename, sep='\\t', comment='#', names=['Param', 'Error', 'StdDev'])\n";
    py << "        plt.figure(figsize=(10, 6))\n";
    py << "        plt.errorbar(data['Param'], data['Error'], yerr=data['StdDev'], fmt='-o', ecolor='red', capsize=5)\n";
    py << "        plt.title(title)\n";
    py << "        plt.xlabel(xlabel)\n";
    py << "        plt.ylabel('Relative Error (%)')\n";
    py << "        plt.xscale('log', base=2)\n";
    py << "        plt.grid(True, which=\"both\", ls=\"--\")\n";
    py << "        plt.savefig(output)\n";
    py << "        print(f'Generated {output}')\n";
    py << "    except Exception as e: print(f'Skipping plot: {e}')\n\n";
    py << "plot_file('hll_results.dat', 'HyperLogLog Error vs m', 'Registers (m)', 'hll_plot.png')\n";
    py << "plot_file('rec_results.dat', 'Recordinality Error vs k', 'Sample Size (k)', 'rec_plot.png')\n";
    py.close();
    cout << "Running Python plotting script..." << endl;
    system("python3 plot_results.py"); 
}

// =========================================================
// Experiments
// =========================================================

void run_full_experiment(const vector<string>& stream, size_t true_card, const string& title, bool generate_plots = false) {
    if (stream.empty()) return;

    cout << "\n=============================================================" << endl;
    cout << " DATASET: " << title << " (True Cardinality: " << true_card << ")" << endl;
    cout << "=============================================================" << endl;

    // --- HLL ---
    cout << ">>> HyperLogLog:" << endl;
    cout << "   m   | Avg Est  | Err % | StdDev %" << endl;
    cout << "-------|----------|-------|---------" << endl;
    ofstream hll_file;
    if (generate_plots) { hll_file.open("hll_results.dat"); hll_file << "# M\tRelError\tStdDev\n"; }

    for (int b = 4; b <= 12; b++) {
        int m = 1 << b;
        vector<double> runs;
        for (int t = 0; t < 20; t++) {
            HyperLogLog hll(b, (t + 1) * 1337);
            for (const auto& w : stream) hll.add(w);
            runs.push_back(hll.estimate());
        }
        StatResult s = compute_stats(runs, true_card);
        cout << setw(6) << m << " | " << setw(8) << (int)s.avg << " | " << setw(4) << fixed << setprecision(2) << s.rel_error << "% | " << s.std_dev_percent << "%" << endl;
        if (generate_plots) hll_file << m << "\t" << s.rel_error << "\t" << s.std_dev_percent << endl;
    }

    // --- REC ---
    cout << "\n>>> Recordinality:" << endl;
    cout << "   k   | Avg Est  | Err % | StdDev %" << endl;
    cout << "-------|----------|-------|---------" << endl;
    ofstream rec_file;
    if (generate_plots) { rec_file.open("rec_results.dat"); rec_file << "# K\tRelError\tStdDev\n"; }

    for (int k = 16; k <= 512; k *= 2) {
        vector<double> runs;
        for (int t = 0; t < 20; t++) {
            Recordinality rec(k, (t + 1) * 777);    
            for (const auto& w : stream) rec.add(w);
            runs.push_back(rec.estimate());
        }
        StatResult s = compute_stats(runs, true_card);
        cout << setw(6) << k << " | " << setw(8) << (int)s.avg << " | " << setw(4) << fixed << setprecision(2) << s.rel_error << "% | " << s.std_dev_percent << "%" << endl;
        if (generate_plots) rec_file << k << "\t" << s.rel_error << "\t" << s.std_dev_percent << endl;
    }

    cout << "\n>>> Bonus Algorithms (k/m = 256 for comparison):" << endl;
    auto run_algo = [&](string name, double est) {
        double err = abs(est - (double)true_card) / true_card * 100.0;
        cout << setw(10) << name << " | " << setw(8) << (int)est << " | " << fixed << setprecision(2) << err << "%" << endl;
    };
    
    // Just one run for brevity in console, or loop if needed. Let's loop 20 times for avg.
    vector<pair<string, double>> algos;
    vector<double> pcsa_runs, kmv_runs, mc_runs, ads_runs;
    
    for(int t=0; t<20; t++) {
        PCSA pcsa(8, (t+1)*1); // m=256
        KMV kmv(256, (t+1)*2);
        MinCount mc(256, (t+1)*3);
        AdaptiveSampling ads(256, (t+1)*4);
        for(const auto& w : stream) {
            pcsa.add(w); kmv.add(w); mc.add(w); ads.add(w);
        }
        pcsa_runs.push_back(pcsa.estimate());
        kmv_runs.push_back(kmv.estimate());
        mc_runs.push_back(mc.estimate());
        ads_runs.push_back(ads.estimate());
    }
    
    cout << "   Algo    | Avg Est  | Err % | StdDev %" << endl;
    cout << "-----------|----------|-------|---------" << endl;
    
    auto print_bonus = [&](string n, vector<double>& r) {
        StatResult s = compute_stats(r, true_card);
        cout << setw(10) << n << " | " << setw(8) << (int)s.avg << " | " << setw(4) << fixed << setprecision(2) << s.rel_error << "% | " << s.std_dev_percent << "%" << endl;
    };
    
    print_bonus("PCSA", pcsa_runs);
    print_bonus("KMV", kmv_runs);
    print_bonus("MinCount", mc_runs);
    print_bonus("Adaptive", ads_runs);
}

vector<string> generate_zipfian(int N, int n, double alpha) {
    vector<string> stream;
    stream.reserve(N);
    vector<double> cdf(n);
    double c_n = 0.0;
    for (int i = 1; i <= n; i++) c_n += 1.0 / pow(i, alpha);
    double cumsum = 0.0;
    for (int i = 0; i < n; i++) {
        cumsum += (1.0 / pow(i + 1, alpha)) / c_n;
        cdf[i] = cumsum;
    }
    random_device rd; mt19937 gen(rd()); uniform_real_distribution<> dis(0.0, 1.0);
    for (int j = 0; j < N; j++) {
        double r = dis(gen);
        auto it = lower_bound(cdf.begin(), cdf.end(), r);
        stream.push_back(to_string(distance(cdf.begin(), it) + 1));
    }
    return stream;
}

int main() {
    string base_path = "datasets/";
    vector<string> files = {"crusoe.txt", "dracula.txt", "iliad.txt", "mare-balena.txt", "midsummer-nights-dream.txt", "quijote.txt", "valley-fear.txt", "war-peace.txt"};
    for (const string& fname : files) {
        vector<string> data = load_file(base_path + fname);
        string dat_name = fname.substr(0, fname.find_last_of(".")) + ".dat";
        size_t true_card_dat = get_cardinality_from_dat(base_path + dat_name);
        if (true_card_dat == 0) {
            unordered_set<string> distinct(data.begin(), data.end());
            true_card_dat = distinct.size();
        }
        bool make_plots = (fname == "dracula.txt"); 
        run_full_experiment(data, true_card_dat, fname, make_plots);
    }

    // Synthetic Data Memory Analysis: memory impact on synthetic data
    cout << "\n=============================================================" << endl;
    cout << " GAP A: Synthetic Data Analysis (Error vs Memory)" << endl;
    cout << " Generated Zipfian (N=100000, n=10000, alpha=1.0)" << endl;
    cout << "=============================================================" << endl;
    {
        // Generate a standard synthetic dataset
        vector<string> synth_data = generate_zipfian(100000, 10000, 1.0);
        size_t synth_true_card = unordered_set<string>(synth_data.begin(), synth_data.end()).size();
        
        // Run full experiment (sweeps m and k) to show memory impact
        run_full_experiment(synth_data, synth_true_card, "Synthetic (Zipf alpha=1.0)", false);
    }

    // SPECIAL EXPERIMENT: Recordinality without Hashing (Dracula)
    cout << "\n=============================================================" << endl;
    cout << " SPECIAL: Recordinality Without Hash (Raw String Lexicography)" << endl;
    cout << " Dataset: Dracula.txt" << endl;
    cout << "=============================================================" << endl;
    {
        vector<string> data = load_file(base_path + "dracula.txt");
        size_t true_card = get_cardinality_from_dat(base_path + "dracula.dat");
        if(true_card == 0) true_card = unordered_set<string>(data.begin(), data.end()).size();

        cout << "   k   | Avg Est  | Err % | StdDev %" << endl;
        cout << "-------|----------|-------|---------" << endl;

        for (int k = 16; k <= 512; k *= 2) {            
            RecordinalityRaw rec(k);
            for (const auto& w : data) rec.add(w);
            double est = rec.estimate();
            double err = abs(est - (double)true_card) / true_card * 100.0;
            
            cout << setw(6) << k << " | " << setw(8) << (int)est << " | " << setw(4) << fixed << setprecision(2) << err << "% | " << "N/A" << endl;
        }
        cout << "Note: StdDev is N/A because Raw Recordinality is deterministic for a fixed stream order." << endl;
    }

    // Alpha Hypothesis Experiment (Zipfian)
    cout << "\n=============================================================" << endl;
    cout << " Testing Alpha Hypothesis (Robustness to skew)" << endl;
    cout << "=============================================================" << endl;
    // We increase N to ensure we see most of n
    vector<double> alphas = {0.5, 1.0, 1.5, 2.0};
    for (double a : alphas) {
        vector<string> s = generate_zipfian(100000, 5000, a);
        size_t true_c = unordered_set<string>(s.begin(), s.end()).size();
        
        vector<double> hll_runs, rec_runs;
        for(int i=0; i<10; i++) {
            HyperLogLog hll(10, i*11); // m=1024
            Recordinality rec(256, i*22); 
            for(auto& w : s) { hll.add(w); rec.add(w); }
            hll_runs.push_back(hll.estimate());
            rec_runs.push_back(rec.estimate());
        }
        
        StatResult hll_s = compute_stats(hll_runs, true_c);
        StatResult rec_s = compute_stats(rec_runs, true_c);
        
        cout << "Alpha=" << a << " | True=" << true_c 
             << " | HLL(m=1024) Err: " << fixed << setprecision(2) << hll_s.rel_error << "%"
             << " | REC(k=256) Err: " << rec_s.rel_error << "%" << endl;
    }

    generate_plot_script(); 
    return 0;
}